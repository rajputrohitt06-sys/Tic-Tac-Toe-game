# Tic-Tac-Toe

A responsive two-player Tic-Tac-Toe game built with HTML, CSS, and JavaScript.

## Features

- Two-player X and O gameplay
- Win and draw detection
- X and O score counter
- Reset Score button
- New Game button
- Responsive design

## Technologies Used

- HTML5
- CSS3
- JavaScript

## How to Run

Open `index.html` in any modern web browser.
